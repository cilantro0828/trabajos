package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private EditText valor1;
    private EditText valor2;
    private TextView resultado;

    private Button sumar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        valor1=findViewById(R.id.cuadrito1);
                valor2=findViewById(R.id.cuadrito2);
                sumar=findViewById(R.id.button);
                sumar.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int suma= Integer.parseInt (valor1.getText().toString()) + Integer.parseInt (valor2.getText().toString());
                        resultado.setText(suma+"");

                    }
                });
    }
    public void  cambiar_pantalla(View view) {
        Intent c = new Intent(this, MainActivity2.class);
        startActivity(c);
      }
}